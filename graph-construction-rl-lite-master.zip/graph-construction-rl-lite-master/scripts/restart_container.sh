#! /bin/bash
manage_container.sh stop && manage_container.sh up